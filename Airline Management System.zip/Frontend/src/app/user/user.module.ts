export class User {
  userId: number = 0;
  firstName: string = '';
  lastName: string = '';
  emailId: string = '';
  password: string = '';
  role: string = 'client';
}
